using Bokado.Server.Data;
using Bokado.Server.Services;
using Bokado.Server.Dtos;
using Bokado.Server.Interfaces;
using Bokado.Server.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Bokado.Server.Repositories
{
    public class ChallengeRepository : IChallengeRepository
    {
        private readonly SocialNetworkContext _context;
        private readonly NotificationService _notifications;

        Dictionary<int, Func<int, bool>> conditions;

        public ChallengeRepository(SocialNetworkContext context, NotificationService notifications)
        {
            _context = context;
            _notifications = notifications;
            InitializeChallenges();
        }

        private void InitializeChallenges()
        {
            conditions = new Dictionary<int, Func<int, bool>>()
            {
                {
                    1, userId => _context.ChatParticipants
                        .Count(cp => cp.UserId == userId &&
                              DateTime.UtcNow - cp.JoinedAt < TimeSpan.FromDays(7)) >= 3
                },
                {
                    2, userId => _context.Messages
                        .Count(m => m.SenderId == userId &&
                              DateTime.UtcNow - m.SentAt < TimeSpan.FromDays(7)) >= 10
                },
                {
                    3, userId => _context.EventParticipants
                        .Any(ep => ep.UserId == userId &&
                             DateTime.UtcNow - ep.JoinedAt < TimeSpan.FromDays(7))
                },
                {
                    4, userId => _context.Friendships
                        .Count(f => (f.UserId == userId || f.FriendId == userId) &&
                              DateTime.UtcNow - f.CreatedAt < TimeSpan.FromDays(7)) >= 5
                },
                {
                    5, userId => _context.Messages
                        .Where(m => m.SenderId == userId &&
                              DateTime.UtcNow - m.SentAt < TimeSpan.FromDays(7))
                        .Select(m => m.ChatId)
                        .Distinct()
                        .Count() >= 3
                },
                {
                    6, userId => _context.Events
                        .Any(e => e.CreatorId == userId)
                },
                {
                    7, userId => _context.Friendships
                        .Count(f => f.UserId == userId || f.FriendId == userId) >= 7
                },
                {
                    8, userId => _context.Messages
                        .Any(m => m.SenderId == userId &&
                             DateTime.UtcNow - m.SentAt < TimeSpan.FromDays(7) &&
                             m.Attachment.EndsWith(".mp3"))
                },
                {
                    9, userId => _context.Events
                        .Any(e => e.Participants.Any(p => p.UserId == userId) &&
                             DateTime.UtcNow - e.Date <= TimeSpan.FromDays(7) &&
                             DateTime.UtcNow - e.Date >= TimeSpan.Zero)
                },
                {
                    10, userId =>
                    {
                        var user = _context.Users
                            .Include(u => u.UserInterests)
                            .FirstOrDefault(u => u.UserId == userId);

                        return user != null &&
                               user.UserInterests.Any() &&
                               user.BirthDate != null &&
                               user.AvatarUrl != null &&
                               !string.IsNullOrEmpty(user.Bio);
                    }
                },
                {
                    11, userId => _context.Posts.Any(p => p.UserId == userId)
                },
                {
                    12, userId => _context.Posts
                        .Include(p => p.Likes)
                        .Any(p => p.UserId == userId && p.Likes.Count >= 5)
                },
                {
                    13, userId => _context.GroupMembers.Any(gm => gm.UserId == userId)
                },
                {
                    14, userId => _context.Groups.Any(g => g.CreatorId == userId)
                },
                {
                    15, userId => _context.Messages.Any(m =>
                        m.SenderId == userId &&
                        !string.IsNullOrEmpty(m.Attachment) &&
                        (m.Attachment.EndsWith(".jpg") || m.Attachment.EndsWith(".jpeg") ||
                         m.Attachment.EndsWith(".png") || m.Attachment.EndsWith(".gif")))
                },
                {
                    16, userId => _context.Messages.Any(m =>
                        m.SenderId == userId && m.Text.Contains("Відеодзвінок розпочато:"))
                },
                {
                    17, userId => _context.FriendRequests.Count(fr => fr.ToUserId == userId) >= 3
                },
                {
                    18, userId => _context.Friendships
                        .Count(f => f.UserId == userId || f.FriendId == userId) >= 10
                },
                {
                    19, userId => _context.PostLikes.Count(pl => pl.UserId == userId) >= 10
                },
                {
                    20, userId => _context.GroupMembers.Count(gm => gm.UserId == userId) >= 3
                }
            };
        }

        public async Task<IdentityResult> CheckChallenge(int challengeId, int userId)
        {
            Challenge challenge = await _context.Challenges.Where(c => c.ChallengeId == challengeId).FirstOrDefaultAsync();

            if (challenge == null)
            {
                return IdentityResult.Failed(new IdentityError { Description = "There is no such challenge" });
            }

            if (!challenge.IsActive)
            {
                return IdentityResult.Failed(new IdentityError { Description = "Challenge is not active" });
            }

            UserChallenge userChallenge = await _context.UserChallenges.Where(uc =>uc.IsCompleted && uc.UserId == userId && uc.ChallengeId==challengeId).FirstOrDefaultAsync();

            if (userChallenge != null)
            {
                return IdentityResult.Success;
            }

            try
            {
                if (conditions[challengeId].Invoke(userId)==true)
                {
                    userChallenge = new UserChallenge() 
                    { 
                        ChallengeId =  challengeId , 
                        UserId = userId, 
                        IsCompleted = true, 
                        CompletedAt = DateTime.UtcNow
                    };

                    _context.Add(userChallenge);
                    await _context.Users
                        .Where(u => u.UserId == userId)
                        .ExecuteUpdateAsync(setters => setters
                            .SetProperty(u => u.Level, u => u.Level + challenge.Reward)
                        );

                    await _context.SaveChangesAsync();

                    // 🔔 Сповіщення про виконання челенджу
                    var user = await _context.Users.FindAsync(userId);
                    if (user != null)
                        await _notifications.ChallengeCompletedAsync(userId, user.Username, challenge.Title);

                    return IdentityResult.Success;
                }
                return IdentityResult.Failed(new IdentityError { Description = "Challenge failed" });
            }
            catch(Exception ex)
            {
                return IdentityResult.Failed(new IdentityError { Description = ex.Message });
            }
        }

        public async Task<List<ChallengeDto>> GetChallenges(int userId)
        {
            int totalUsers = await _context.Users.CountAsync(u => !u.IsAdmin);

            var completionCounts = await _context.UserChallenges
                .Where(uc => uc.IsCompleted)
                .GroupBy(uc => uc.ChallengeId)
                .Select(g => new { ChallengeId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.ChallengeId, x => x.Count);

            var query = from challenge in _context.Challenges
                        where challenge.IsActive
                        join userChallenge in _context.UserChallenges
                            on new { ChallengeId = challenge.ChallengeId, UserId = userId }
                            equals new { userChallenge.ChallengeId, userChallenge.UserId }
                            into userChallengesGroup
                        from uc in userChallengesGroup.DefaultIfEmpty()
                        select new ChallengeDto
                        {
                            ChallengeId = challenge.ChallengeId,
                            Title = challenge.Title,
                            Description = challenge.Description,
                            Reward = challenge.Reward,
                            CreatedAt = challenge.CreatedAt,
                            CompletedAt = uc != null ? uc.CompletedAt : null
                        };

            var list = await query.ToListAsync();

            foreach (var dto in list)
            {
                int count = completionCounts.GetValueOrDefault(dto.ChallengeId, 0);
                dto.CompletionRate = totalUsers > 0
                    ? Math.Round((double)count / totalUsers * 100, 1)
                    : 0;
            }

            return list;
        }
    }
}
